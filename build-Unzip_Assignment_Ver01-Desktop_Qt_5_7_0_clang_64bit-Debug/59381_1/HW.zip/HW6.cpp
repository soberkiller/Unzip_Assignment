#include <iostream>

using namespace std;

#define PI 3.1415926;

int main(){

  cout << "hello world!";

}
